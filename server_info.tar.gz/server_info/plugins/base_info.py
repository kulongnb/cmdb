import subprocess


class Base():
    def __init__(self, debug):
        pass

    def run_cmd(self, date):
        stat, result = subprocess.getstatusoutput(date)
        if not stat:
            return self.parser(result)

    def get_base(self):
        ssh_all = "ssh stus@10.0.122.124 "
        result = {
            # 'os_name':
            'os_name': self.run_cmd(date=f'{ssh_all} "uname -s"').strip(),
            # 'machine':
            'machine': self.run_cmd(date=f'{ssh_all} "uname -m"').strip(),
            # 'os_version':
            'os_version': self.run_cmd("cat /etc/redhat-release || cat /etc/issue|tr ' ' '_'").strip().split('\n')[0],
            # 'hostname':
            'hostname': self.run_cmd(date=f'{ssh_all} "hostname"').strip(),
            # 'kernel':
            'kernel': self.run_cmd(date=f"{ssh_all}  'uname -rv'|tr '  ' '_' ")
        }
        return result
    # def __init__():

    def parser(self, data):
        if data.endswith('_'):
            data = data[:-1]
        return data
        # ssh_all="ssh stus@10.0.122.124 "
        # date=f'{ssh_all} "uname -s"'
    # def insert_mysql(self,date):
    #         import pymysql
    #         conn = pymysql.connect(host='172.17.0.2',
    #                         port=3306,
    #                         user='root',
    #                         passwd='QFedu123!',
    #                         db='liu',
    #                         charset='utf8mb4')
    #         cursor = conn.cursor()
    #         many_sql = "insert into cpu_info (model_name, cpu_type,physial_count,physial_cores) values(%s, %s,%s,%s)"

    #         row = cursor.execute(many_sql, date)

    #         conn.commit()
    #         cursor.close()
    #         conn.close()
    def cmd_handle(self):
        return self.get_base()


class Cpu(Base):
    def __init__(self, debug):
        pass

    def get_cpu(self):
        self.cat_all = "cat /root/xiangmv/task/kulong/server_info/R710-Memory-info"
        result = {
            # cpu 名字
            # 'model_name':
            'model_name': self.run_cmd(f"{self.cat_all}|grep 'model name' /proc/cpuinfo | uniq |cut -d: -f2|tr -s ' '|tr ' ' '_'"),
            # 类型
            # 'cpu_type':
            'cpu_type': self.run_cmd('uname -p'),
            # 物理颗数
            # 'physical_count':
            'physical_count': int(self.run_cmd(f"{self.cat_all}|grep 'physical id' /proc/cpuinfo | sort -u | wc -l").strip()),
            # 每颗物理 cpu 的核心数
            # 'physical_cores':
            'physical_cores': int(self.run_cmd(f"{self.cat_all}|grep 'cpu cores' /proc/cpuinfo | uniq |cut -d: -f2").strip()),
        }
        return result

    def cmd_handle(self):
        return self.get_cpu()
# obj=Cpu()





# if __name__ == '__main__':
#         mybase = Base() #实例化
# #     info = mybase
#         info=mybase.get_cpu()
#         print(info)

    # m=run_cmd(date=f'{ssh_all} "uname -s"').strip()
    # a=run_cmd(f"{cat_all}|grep 'model name' /proc/cpuinfo | uniq |cut -d: -f2")
    # print(m)

    # """
    # 操作系统 uname -s
    # 系统版本信息uname -m
    # 主机名
    # 内核信息
    # # """

# import pymysql
# conn = pymysql.connect(host='172.17.0.2',
#                 port=3306,
#                 user='root',
#                 passwd='QFedu123!',
#                 db='liu',
#                 charset='utf8mb4')


# cursor = conn.cursor()
# many_sql = "insert into uname_info(os_name, macgine,os_version,hostname,kernel) values(%s, %s,%s,%s,%s)"

# #                 # 一次插入多条数据
# cursor.execute(many_sql,all_mem_info)

# conn.commit()
# cursor.close()
# conn.close()
