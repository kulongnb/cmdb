import subprocess


class Memory():
    def __init__(self, debug):
        self.file = "R710-Memory-info"
        if debug:
            self.cmd = "grep -v '^$' %s" % self.file
        else:
            self.cmd = "dmidecode -q -t 17|grep -v '^$' "
        self.debug = debug

    def run_cmd(self, cmd):
        stat, result = subprocess.getstatusoutput(cmd)
        if not stat:
            return self.parse(result)

    def parse(self, data):
        info_mem = {}
        key_map = {
            'Size': 'capacity',
            'Locator': 'slot',
            'Type': 'model',
            'Speed': 'speed',
            'Manufacturer': 'manufacturer',
            'Serial Number': 'sn',
        }
        memory_list = [mem for mem in data.split('Memory Device') if mem]

        for item in memory_list:
            single_slot = {}

            for line in item.splitlines():
                line = line.strip()
                if len(line.split(':')) == 2:
                    key, val = line.split(':')
                    key, val = key.strip(), val.strip()

                    if key in key_map:
                        single_slot[key_map[key]] = val

            info_mem[single_slot["slot"]] = single_slot
        # print(len(info_/mem))
        return info_mem

    def cmd_handle(self):
        """获取R710数据接口"""
        return self.run_cmd(self.cmd)


class Disk(Memory):
    def __init__(self, debug):
        self.file = "R710-disk-info"
        self.cmd = "grep -v '^$' %s" % self.file
        

    def parse(self, data):
        info_disk = {}
        key_map = {
            'Raw Size': 'raw',  # 原始磁盘容量
            'Slot Number': 'slot',  # 插槽号
            'PD Type': 'pd',  # 接口类型
            'Coerced Size': 'coreced'  # 强制磁盘容量
        }
        disk_list = [disk for disk in data.split(
            'Enclosure Device ID: 32') if disk]

        for item in disk_list:
            single_slot = {}

            for line in item.splitlines():
                line = line.strip()
                if len(line.split(':')) == 2:
                    key, val = line.split(':')
                    key, val = key.strip(), val.strip()

                    if key in key_map:
                        single_slot[key_map[key]] = val

            info_disk[single_slot["slot"]] = single_slot
        # print(info_disk)
        return info_disk

    def cmd_handle(self):
        """获取R710数据接口"""
        return self.run_cmd(self.cmd)

# d=Disk(debug=True)
# d.cmd_handle()

# if __name__ == '__main__':
#     mem_obj = Memory(debug=True)  # 实例化
#     info = mem_obj.cmd_handle()
#     for key in info:
#         print(key)
# disk_mem=$(grep "PD Type" R710-disk-info |awk -F ': ' '{print $2}')
#     disk_size=$(grep "Raw Size" R710-disk-info |awk -F ': ' '{print $2}'|awk '{print $1,$2}')
#     disk_num=$(grep "Slot Number" R710-disk-info |awk -F ': ' '{print $2}')
