from core.main import main

if __name__=='__main__':
    all_server_info=main()
    print(all_server_info)

