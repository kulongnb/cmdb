server_info_dict={
    # 可以动态更新模块
    'cpu':'plugins.base_info.Cpu',
    'base':'plugins.base_info.Base',
    'mem':'plugins.Mem_info.Memory',
    'disk':'plugins.Mem_info.Disk',

}





